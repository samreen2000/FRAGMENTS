package com.example.airuniversityportal;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class LoginFragment extends Fragment {

    Button frgLogin;
    Intent Login_intent;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View login_view= inflater.inflate(R.layout.fragment_login, container, false);
        frgLogin=login_view.findViewById(R.id.btn_frg_login);
        Login_intent= new Intent(getActivity(),MainDashBoardActivity.class);

        frgLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(Login_intent);
            }
        });
        return login_view;
    }
}