package com.example.airuniversityportal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.app.FragmentBreadCrumbs;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class LoginandRegister extends AppCompatActivity {

    Button login;
    Button register;
    FragmentBreadCrumbs frg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginand_register);

        login=findViewById(R.id.btn_act_login);
        register=findViewById(R.id.btn_act_register);
        frg=findViewById(R.id.frg_LoginAndRegister);

        LoginFragment f1=new LoginFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frg_LoginAndRegister,f1);
        transaction.commit();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginFragment f1=new LoginFragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frg_LoginAndRegister,f1);
                transaction.commit();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RegisterFragment f2=new RegisterFragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frg_LoginAndRegister,f2);
                transaction.commit();
            }
        });

    }
}